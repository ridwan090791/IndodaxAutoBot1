
package com.example.indodaxautobot

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.*
import kotlin.concurrent.timer

class BotService : Service() {

    private var timerTask: Timer? = null
    private val client = OkHttpClient()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val apiKey = intent?.getStringExtra("API_KEY") ?: ""
        val apiSecret = intent?.getStringExtra("API_SECRET") ?: ""

        timerTask = timer(period = 60000) {
            try {
                val url = "https://indodax.com/api/ticker/btc_idr"
                val request = Request.Builder().url(url).build()
                val response = client.newCall(request).execute()
                val json = JSONObject(response.body?.string() ?: "{}")
                val lastPrice = json.getJSONObject("ticker").getString("last")

                Log.i("IndodaxBot", "Harga BTC/IDR: $lastPrice - Auto trading EMA berjalan...")
                // Di sini strategi EMA akan dijalankan
            } catch (e: Exception) {
                Log.e("IndodaxBot", "Error: ${e.message}")
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
