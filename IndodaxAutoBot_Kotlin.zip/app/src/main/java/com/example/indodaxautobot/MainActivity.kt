
package com.example.indodaxautobot

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val apiKeyInput = findViewById<EditText>(R.id.apiKeyInput)
        val apiSecretInput = findViewById<EditText>(R.id.apiSecretInput)
        val startBtn = findViewById<Button>(R.id.startBotBtn)

        startBtn.setOnClickListener {
            val intent = Intent(this, BotService::class.java)
            intent.putExtra("API_KEY", apiKeyInput.text.toString())
            intent.putExtra("API_SECRET", apiSecretInput.text.toString())
            startService(intent)
        }
    }
}
